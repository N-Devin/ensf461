#include "util.h"
#define MAX_LINE_LENGTH 1024
#include <math.h>
#include <stdio.h>
#include <string.h>

int* read_next_line(FILE* fin) {
    // TODO: This function reads the next line from the input file
    // The line is a comma-separated list of integers
    // Return the list of integers as an array where the first element
    // is the number of integers in the rest of the array
    // Return NULL if there are no more lines to read

    char line[1024];
    if (fgets(line, sizeof(line), fin) == NULL) {
        return NULL;
    }

    // Initially allocate space for 10 numbers
    int initial_size = 10;
    int* numbers = malloc((initial_size + 1) * sizeof(int)); // +1 to store the count
    if (numbers == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    int count = 0;
    char* token = strtok(line, ",");
    while (token != NULL) {
        if (count >= initial_size) {
            initial_size = 2; // Double the size
            numbers = (int*)realloc(numbers, (initial_size + 1) * sizeof(int)); // +1 to store the count

            if (numbers == NULL) {
                fprintf(stderr, "Memory allocation failed\n");
                exit(1);
            }
        }

        numbers[count + 1] = atoi(token); // +1 because numbers[0] will store the count
        token = strtok(NULL, ",");
        count++;
    }

    numbers[0] = count;
    return numbers;
    }



float compute_average(int* line) {
    // TODO: Compute the average of the integers in the vector
    // Recall that the first element of the vector is the number of integers
    int num_integers = line[0];
    float sum = 0.0;
    for (int i = 1; i <= num_integers; i++) {
        sum += line[i];
    }
    return (float) sum / num_integers;
}

float compute_stdev(int* line) {
    // TODO: Compute the standard deviation of the integers in the vector
    // Recall that the first element of the vector is the number of integers
    int num_integers = line[0];
    float mean = compute_average(line);
    float sum_squared_diff = 0.0;
    for (int i = 1; i <= num_integers; i++) {
        float diff = line[i] - mean;
        sum_squared_diff += diff * diff;
    }
    return (float) sqrt(sum_squared_diff / num_integers);
}